=== Dot Blog ===
Contributors: HighThemes
Requires at least: WordPress 4.5
Tested up to: WordPress 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, news, education, one-column, right-sidebar, left-sidebar,custom-colors,editor-style, featured-images, footer-widgets, full-width-template, post-formats, sticky-post, theme-options, threaded-comments, translation-ready

== Description ==
Dot Blog is a free blogging WordPress theme best suited for blogs, personal sites, magazines, etc. If you’re starting an online magazine and need a clean modern design, trying Dot Blog won’t disappoint you!

For more information about Dot Blog please go to https://highthemes.com/themes/dot-blog/.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in Dot Blog in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
5. Navigate to Appearance > Customize in your admin panel and customize to taste.

== Frequently Asked Questions ==

= A question that someone might have =

== Changelog ==


== Resources ==
hoverIntent, Copyright 2013 Brian Cherne
Licenses: MIT

jQuery Superfish Menu, Copyright (c) 2013 Joel Birch
License: Dual licensed under the MIT and GPL

sidr, Copyright (c) 2013-2016 Alberto Varela
License: MIT

jQuery slicknav by Josh
License: MIT

Bootstrap v3.3.6, Copyright 2011-2015 Twitter, Inc.
Licenses: MIT

slick, Copyright (c) 2014 Ken Wheeler
License : MIT

Abstract base class for collection plugins, Written by Keith Wood (kbwood{at}iinet.com.au) December 2013
License: MIT

FitVids, Copyright 2013, Chris Coyier
License: WTFPL

Font Awesome icons, Copyright Dave Gandy
License: SIL Open Font License, version 1.1.
Source: http://fontawesome.io/

Image Resources
https://pixabay.com/en/auto-renault-juvaquatre-pkw-old-1661009/
https://pixabay.com/en/boots-cup-daylight-shoes-grass-1853852/
https://pixabay.com/en/fresh-orange-juice-squeezed-1614822/
https://pixabay.com/en/girls-children-tulips-netherlands-739071/
https://unsplash.com/@kalenemsley?photo=kGSapVfg8Kw
https://www.pexels.com/photo/bed-cute-dog-female-206396/
https://www.pexels.com/photo/mountain-ranges-under-blue-sky-192651/
